package com.azkivip.snapview.client.gui;

import com.azkivip.snapview.client.screenshot.ScreenshotEntry;
import com.azkivip.snapview.client.screenshot.ScreenshotRepository;
import com.azkivip.snapview.client.thumbnail.ThumbnailLoader;
import com.azkivip.snapview.client.thumbnail.ThumbnailTexture;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * Screenshot gallery grid with virtual scrolling.
 */
public final class GalleryScreen extends Screen {

    private static final int PADDING = 8;
    private static final int CELL_WIDTH = ThumbnailLoader.THUMB_WIDTH + PADDING;
    private static final int CELL_HEIGHT = ThumbnailLoader.THUMB_HEIGHT + PADDING + 12;
    private static final int TOP_BAR_HEIGHT = 32;

    private final Screen parent;
    private final ScreenshotRepository repository;
    private final ThumbnailLoader thumbnailLoader;

    private int columns = 1;
    private double scrollOffset = 0;
    private int hoveredIndex = -1;

    public GalleryScreen(Screen parent, ScreenshotRepository repository, ThumbnailLoader thumbnailLoader) {
        super(Component.translatable("snapview.gallery.title"));
        this.parent = parent;
        this.repository = repository;
        this.thumbnailLoader = thumbnailLoader;
    }

    @Override
    protected void init() {
        columns = Math.max(1, (this.width - PADDING) / CELL_WIDTH);

        addRenderableWidget(Button.builder(Component.translatable("snapview.gallery.back"),
                        button -> onClose())
                .bounds(PADDING, PADDING, 80, 20)
                .build());

        if (!repository.isLoaded()) {
            repository.refreshAsync(this.minecraft::execute, entries -> {
            });
        }
    }

    @Override
    public void onClose() {
        thumbnailLoader.releaseAll();
        this.minecraft.setScreen(parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);

        List<ScreenshotEntry> entries = repository.entries();

        if (!repository.isLoaded()) {
            graphics.centeredText(this.font, Component.translatable("snapview.gallery.loading"),
                    this.width / 2, this.height / 2, 0xFFFFFF);
            return;
        }

        if (entries.isEmpty()) {
            graphics.centeredText(this.font, Component.translatable("snapview.gallery.empty"),
                    this.width / 2, this.height / 2, 0xAAAAAA);
            return;
        }

        int viewportTop = TOP_BAR_HEIGHT;
        int viewportBottom = this.height;
        int totalRows = (entries.size() + columns - 1) / columns;
        int contentHeight = totalRows * CELL_HEIGHT;
        clampScroll(contentHeight, viewportBottom - viewportTop);

        int firstVisibleRow = Math.max(0, (int) (scrollOffset / CELL_HEIGHT) - 1);
        int lastVisibleRow = Math.min(totalRows - 1,
                (int) ((scrollOffset + (viewportBottom - viewportTop)) / CELL_HEIGHT) + 1);

        hoveredIndex = -1;

        for (int row = firstVisibleRow; row <= lastVisibleRow; row++) {
            int rowTop = viewportTop + (row * CELL_HEIGHT) - (int) scrollOffset;

            for (int col = 0; col < columns; col++) {
                int index = row * columns + col;
                if (index >= entries.size()) {
                    break;
                }

                int cellX = PADDING + col * CELL_WIDTH;
                int cellY = rowTop;

                if (cellY + CELL_HEIGHT < viewportTop || cellY > viewportBottom) {
                    continue;
                }

                ScreenshotEntry entry = entries.get(index);
                boolean hovered = mouseX >= cellX && mouseX < cellX + ThumbnailLoader.THUMB_WIDTH
                        && mouseY >= cellY && mouseY < cellY + ThumbnailLoader.THUMB_HEIGHT
                        && mouseY >= viewportTop;
                if (hovered) {
                    hoveredIndex = index;
                }

                renderCell(graphics, entry, cellX, cellY, hovered);
            }
        }
    }

    private void renderCell(GuiGraphicsExtractor graphics, ScreenshotEntry entry, int x, int y, boolean hovered) {
        graphics.fill(x, y, x + ThumbnailLoader.THUMB_WIDTH, y + ThumbnailLoader.THUMB_HEIGHT, 0xFF1E1E1E);

        ThumbnailTexture texture = thumbnailLoader.peek(entry);
        if (texture == null) {
            thumbnailLoader.request(entry, t -> {
            });
        } else {
            drawThumbnail(graphics, texture, x, y);
        }

        if (hovered) {
            graphics.outline(x - 1, y - 1, ThumbnailLoader.THUMB_WIDTH + 2, ThumbnailLoader.THUMB_HEIGHT + 2, 0xFFFFFFFF);
        }

        graphics.text(this.font, trimmedLabel(entry.fileName()),
                x, y + ThumbnailLoader.THUMB_HEIGHT + 2, 0xAAAAAA, false);
    }

    private void drawThumbnail(GuiGraphicsExtractor graphics, ThumbnailTexture texture, int x, int y) {
        // 26.1 blit overload: blit(Identifier, x, y, w, h, u0, v0, u1, v1)
        // UV coordinates are floats in 0..1 space. We sample the whole texture.
        graphics.blit(texture.id(), x, y,
                ThumbnailLoader.THUMB_WIDTH, ThumbnailLoader.THUMB_HEIGHT,
                0.0f, 0.0f, 1.0f, 1.0f);
    }

    private String trimmedLabel(String fileName) {
        String withoutExtension = fileName.endsWith(".png")
                ? fileName.substring(0, fileName.length() - 4)
                : fileName;
        int maxChars = CELL_WIDTH / 6;
        return withoutExtension.length() > maxChars
                ? withoutExtension.substring(0, maxChars - 1) + "\u2026"
                : withoutExtension;
    }

    private void clampScroll(int contentHeight, int viewportHeight) {
        double maxScroll = Math.max(0, contentHeight - viewportHeight);
        scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollOffset -= scrollY * (CELL_HEIGHT / 2.0);
        if (scrollOffset < 0) {
            scrollOffset = 0;
        }
        return true;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0 && hoveredIndex >= 0) {
            List<ScreenshotEntry> entries = repository.entries();
            if (hoveredIndex < entries.size()) {
                this.minecraft.setScreen(new ScreenshotViewerScreen(this, repository, entries, hoveredIndex));
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
